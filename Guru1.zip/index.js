// import ask-sdk-core
const Alexa = require('ask-sdk-core')
const axios = require('axios');

// skill name
const appName = 'Guru'

// code for the handlers

function getCollege(city, state) {
  const apikey = 'JFM2YSQEbov857TgMahcszTgdVhh4WSsjl3FMsEg';

  return axios.get(`https://api.data.gov/ed/collegescorecard/v1/schools?api_key=${apikey}&school.city=${city}&school.state=${state}&fields=id,ope6_id,ope8_id,school.name,2013.student.size,school.zip,school.city,school.state`).then((response) => {
    return response.results;
  });
}

const LaunchRequestHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'LaunchRequest';
  },
  handle(handlerInput) {
    // welcome message
    let speechText = 'Welcome to Guru';
    // welcome screen message
    let displayText = 'Welcome to Guru'

    return handlerInput.responseBuilder
      .speak(speechText)
      .reprompt(speechText)
      .withSimpleCard(appName, displayText)
      .getResponse();
  }
};

// implement custom handlers
const SearchIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest' && handlerInput.requestEnvelope.request.intent.name === 'searchIntent'
  },
  handle(handlerInput) {
    let speechText = '';
    let displayText = '';
    let intent = handlerInput.requestEnvelope.request.intent;
    let city = intent.slots.city.value;
    let state = intent.slots.state.value;

    if (state && city) {
      return getCollege(city, state).then((results) => {
        const result = results.school.name
        const speechText = `${result}`;

        displayText = '${result}'

        return handlerInput.responseBuilder
          .speak(speechText)
          .withSimpleCard(appName, displayText)
          .withShouldEndSession(true)
          .getResponse();
      })
    } else {
      return handlerInput.responseBuilder
        .addDelegateDirective(intent)
        .getResponse();
    }
  }
}


// end Custom handlers

const HelpIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
      handlerInput.requestEnvelope.request.intent.name === 'AMAZON.HelpIntent';
  },
  handle(handlerInput) {
    // help text for your skill
    let speechText = '';

    return handlerInput.responseBuilder
      .speak(speechText)
      .reprompt(speechText)
      .withSimpleCard(appName, speechText)
      .getResponse();
  }
};

const CancelAndStopIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && (handlerInput.requestEnvelope.request.intent.name === 'AMAZON.CancelIntent'
        || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StopIntent');
  },
  handle(handlerInput) {
    let speechText = 'Goodbye';

    return handlerInput.responseBuilder
      .speak(speechText)
      .withSimpleCard(appName, speechText)
      .getResponse();
  }
};

const SessionEndedRequestHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'SessionEndedRequest';
  },
  handle(handlerInput) {
    // any cleanup logic goes here
    return handlerInput.responseBuilder.getResponse();
  }
};

// Lambda handler function
// Remember to add custom request handlers here
exports.handler = Alexa.SkillBuilders.custom()
  .addRequestHandlers(LaunchRequestHandler,
    SearchIntentHandler,
    HelpIntentHandler,
    CancelAndStopIntentHandler,
    SessionEndedRequestHandler).lambda();
