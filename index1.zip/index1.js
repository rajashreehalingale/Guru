
const Alexa = require('ask-sdk-core')

const LaunchRequestHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'LaunchRequest';
  },
  async handle(handlerInput) {
       return handlerInput.responseBuilder
          .speak('testing')
          .getResponse();
  }
}

const searchTypeIntentHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest' && handlerInput.requestEnvelope.request.intent.name === 'searchTypeIntent'
  },
   handle(handlerInput) {
    let intent = handlerInput.requestEnvelope;
    let speechText = intent.slots.searchType.value;;
   
      return handlerInput.responseBuilder
      .speak(speechText)
      .getResponse();  
  }
}
const SessionEndedRequestHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'SessionEndedRequest';
  },
  handle(handlerInput) {
    // any cleanup logic goes here
    return handlerInput.responseBuilder.getResponse();
  }
};

// Lambda handler function
// Remember to add custom request handlers here
exports.handler = Alexa.SkillBuilders.custom()
  .withApiClient(new Alexa.DefaultApiClient())
  .addRequestHandlers(LaunchRequestHandler,
    searchTypeIntentHandler,
    SessionEndedRequestHandler)

  .lambda();